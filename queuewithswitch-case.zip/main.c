/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>

int main()
{
    int queue[10], i, n, x, front = -1, rear = -1, choice;

    printf("Enter the size of Queue: ");
    scanf("%d", &n);

    while (1)
    {
        printf("\n1. Enqueue:Insertion of element in queue");
        printf("\n2. Dequeue:Deletion of element in queue");
        printf("\n3. underflow:check whwether the Queue is empty");
        printf("\n4. overflow:check whether the Queue is full");
        printf("\n5. peek:show topmost element");
        printf("\n6. Display:show the element in the Queue");
        printf("\n7. Exit");
        printf("\nEnter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
            case 1:
                // Enqueue
                printf("\nEnter the element for insertion in queue: ");
                scanf("%d", &x);
                if (rear == n - 1)
                {
                    printf("\nQueue Overflow");
                }
                else if(front == -1 && rear == -1)
                {
                    front = rear = 0;
                    queue[rear] = x;
                }
                else
                {
                    rear++;
                    queue[rear] = x;
                }
                break;

            case 2:
                // Dequeue
                printf("\n Enter the element for deletion in queue");
                scanf("%d",&x);
                if(front==-1 && rear==-1)
                {
                    printf("underflow");
                }
                else if(front==rear)
                {
                    printf("\n Element Deleted from Queue:%d",queue[front]);
                    front=rear=-1;
                }
                else
                {
                    printf("\n Element Deleted from Queue:%d",queue[front]);
                    front++;
                } 
                break;
                    
                

            case 3:
                //Underflow
                if(front==-1 && rear==-1)
                {
                    printf("Queue is empty: underflow");
                }
                else
                {
                    printf("Queue is not empty");
                }
                break;

            case 4:
                // Check Overflow
                if (rear==n-1)
                {
                    printf("overflow");
                }
                else
                {
                    printf("Queue is not overflow");
                }
                break;

            case 5:
                // Peek: show first element
                printf("The element at first position is %d",queue[front]);
                break;
                
            case 6:
            //Display
            for(int i=front;i<=rear;i++)
            {
                printf("%d\t",queue[i]);
            }
            break;

            case 7:
                // Exit
                exit(0);
                break;

            default:
                printf("\nInvalid choice");
        }
    }

    return 0;
}
